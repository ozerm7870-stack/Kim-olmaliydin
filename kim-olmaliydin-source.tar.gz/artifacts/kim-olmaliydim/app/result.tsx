import React, { useEffect, useRef } from "react";
import {
  Animated,
  Dimensions,
  Easing,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { ParticleField } from "@/components/ParticleField";

const { width } = Dimensions.get("window");

type Country = {
  name: string;
  flag: string;
  city: string;
  description: string;
  code: string;
  vibe: string;
};

const COUNTRIES: Country[] = [
  {
    name: "JAPONYA",
    flag: "🇯🇵",
    city: "Tokyo",
    code: "JPN",
    description: "Ruhun Tokyo'nun ışıklarına ait!",
    vibe: "Disiplin, estetik ve huzur senin özündedir.",
  },
  {
    name: "İTALYA",
    flag: "🇮🇹",
    city: "Roma",
    code: "ITA",
    description: "Ruhun Roma'nın sokaklarında yaşıyor!",
    vibe: "Tutku, sanat ve güzellik senin dilinden konuşur.",
  },
  {
    name: "BREZİLYA",
    flag: "🇧🇷",
    city: "Rio de Janeiro",
    code: "BRA",
    description: "Ruhun Rio'nun ritmine doğmuş!",
    vibe: "Özgürlük, neşe ve sonsuz enerji seni tanımlar.",
  },
  {
    name: "İZLANDA",
    flag: "🇮🇸",
    city: "Reykjavik",
    code: "ISL",
    description: "Ruhun kuzey ışıklarıyla dans ediyor!",
    vibe: "Gizemlilik, sessizlik ve sonsuzluk senin içinde.",
  },
  {
    name: "TÜRKİYE",
    flag: "🇹🇷",
    city: "İstanbul",
    code: "TUR",
    description: "Ruhun iki kıtanın kavşağında yaşıyor!",
    vibe: "Tarih, derin bağ ve sıcaklık senin özündedir.",
  },
];

function getRandomCountry(): Country {
  return COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
}

export default function ResultScreen() {
  const insets = useSafeAreaInsets();
  const country = useRef(getRandomCountry()).current;

  const cardScale = useRef(new Animated.Value(0.7)).current;
  const cardOpacity = useRef(new Animated.Value(0)).current;
  const cardRotate = useRef(new Animated.Value(-5)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;
  const labelOpacity = useRef(new Animated.Value(0)).current;
  const descOpacity = useRef(new Animated.Value(0)).current;
  const buttonOpacity = useRef(new Animated.Value(0)).current;
  const flagScale = useRef(new Animated.Value(0)).current;
  const stampAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    Animated.sequence([
      Animated.parallel([
        Animated.spring(cardScale, {
          toValue: 1,
          friction: 7,
          tension: 60,
          useNativeDriver: false,
        }),
        Animated.timing(cardOpacity, {
          toValue: 1,
          duration: 400,
          useNativeDriver: false,
        }),
        Animated.spring(cardRotate, {
          toValue: 0,
          friction: 7,
          tension: 60,
          useNativeDriver: false,
        }),
      ]),
      Animated.delay(100),
      Animated.spring(flagScale, {
        toValue: 1,
        friction: 5,
        tension: 120,
        useNativeDriver: false,
      }),
      Animated.delay(150),
      Animated.timing(stampAnim, {
        toValue: 1,
        duration: 300,
        easing: Easing.out(Easing.back(2)),
        useNativeDriver: false,
      }),
      Animated.delay(100),
      Animated.timing(labelOpacity, {
        toValue: 1,
        duration: 500,
        useNativeDriver: false,
      }),
      Animated.timing(descOpacity, {
        toValue: 1,
        duration: 500,
        useNativeDriver: false,
      }),
      Animated.timing(buttonOpacity, {
        toValue: 1,
        duration: 400,
        useNativeDriver: false,
      }),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 1,
          duration: 1800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
        Animated.timing(glowAnim, {
          toValue: 0,
          duration: 1800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
      ])
    ).start();
  }, []);

  const cardRotateInterp = cardRotate.interpolate({
    inputRange: [-5, 0],
    outputRange: ["-5deg", "0deg"],
  });

  const glowOpacity = glowAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.5, 1],
  });

  const stampScale = stampAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [2, 1],
  });

  return (
    <View style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <ParticleField />

      <View style={styles.header}>
        <Text style={styles.headerLabel}>SONUÇ</Text>
        <View style={styles.headerLine} />
      </View>

      <Animated.View
        style={[
          styles.cardWrapper,
          {
            opacity: cardOpacity,
            transform: [
              { scale: cardScale },
              { rotate: cardRotateInterp },
            ],
          },
        ]}
      >
        <Animated.View style={[styles.cardGlow, { opacity: glowOpacity }]} />
        <View style={styles.card}>
          <View style={styles.cardCornerTL} />
          <View style={styles.cardCornerTR} />
          <View style={styles.cardCornerBL} />
          <View style={styles.cardCornerBR} />

          <View style={styles.cardTop}>
            <View style={styles.passportLabel}>
              <Text style={styles.passportLabelText}>RUH PASAPORTU</Text>
            </View>
            <View style={styles.passportCode}>
              <Text style={styles.passportCodeText}>{country.code}</Text>
            </View>
          </View>

          <View style={styles.cardCenter}>
            <Animated.Text
              style={[styles.flag, { transform: [{ scale: flagScale }] }]}
            >
              {country.flag}
            </Animated.Text>
          </View>

          <View style={styles.cardBottom}>
            <View style={styles.cardDataRow}>
              <View style={styles.cardDataItem}>
                <Text style={styles.cardDataLabel}>ÜLKE</Text>
                <Text style={styles.cardDataValue}>{country.name}</Text>
              </View>
              <View style={styles.cardDataItem}>
                <Text style={styles.cardDataLabel}>ŞEHİR</Text>
                <Text style={styles.cardDataValue}>{country.city.toUpperCase()}</Text>
              </View>
            </View>

            <View style={styles.cardDivider} />

            <View style={styles.cardDataItem}>
              <Text style={styles.cardDataLabel}>RUH TİPİ</Text>
              <Text style={[styles.cardDataValue, styles.cardDataValueFull]}>
                {country.vibe}
              </Text>
            </View>
          </View>

          <Animated.View
            style={[
              styles.stamp,
              {
                transform: [{ scale: stampScale }],
                opacity: stampAnim,
              },
            ]}
          >
            <Text style={styles.stampText}>ONAYLANDI</Text>
          </Animated.View>
        </View>
      </Animated.View>

      <Animated.View style={[styles.descContainer, { opacity: descOpacity }]}>
        <View style={styles.quoteBar} />
        <Text style={styles.description}>{country.description}</Text>
      </Animated.View>

      <Animated.View style={[styles.buttonContainer, { opacity: buttonOpacity }]}>
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            router.back();
          }}
          style={({ pressed }) => [
            styles.retryButton,
            { opacity: pressed ? 0.75 : 1 },
          ]}
        >
          <Text style={styles.retryButtonText}>TEKRAR DENE</Text>
        </Pressable>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  header: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingTop: 8,
  },
  headerLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    color: Colors.neonCyan,
    letterSpacing: 4,
  },
  headerLine: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.border,
  },
  cardWrapper: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    width: "100%",
  },
  cardGlow: {
    position: "absolute",
    width: width * 0.85 + 60,
    height: 400,
    backgroundColor: Colors.neonCyanGlow,
    borderRadius: 40,
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 60,
    elevation: 20,
  },
  card: {
    width: width * 0.82,
    borderWidth: 1,
    borderColor: Colors.neonCyan,
    backgroundColor: Colors.card,
    padding: 20,
    gap: 16,
    position: "relative",
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 10,
    overflow: "hidden",
  },
  cardCornerTL: {
    position: "absolute",
    top: -2,
    left: -2,
    width: 16,
    height: 16,
    borderTopWidth: 2,
    borderLeftWidth: 2,
    borderColor: Colors.neonCyan,
  },
  cardCornerTR: {
    position: "absolute",
    top: -2,
    right: -2,
    width: 16,
    height: 16,
    borderTopWidth: 2,
    borderRightWidth: 2,
    borderColor: Colors.neonCyan,
  },
  cardCornerBL: {
    position: "absolute",
    bottom: -2,
    left: -2,
    width: 16,
    height: 16,
    borderBottomWidth: 2,
    borderLeftWidth: 2,
    borderColor: Colors.neonCyan,
  },
  cardCornerBR: {
    position: "absolute",
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderBottomWidth: 2,
    borderRightWidth: 2,
    borderColor: Colors.neonCyan,
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  passportLabel: {
    borderWidth: 1,
    borderColor: Colors.neonCyanGlow,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  passportLabelText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 9,
    color: Colors.neonCyan,
    letterSpacing: 3,
  },
  passportCode: {},
  passportCodeText: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    color: "rgba(0, 245, 255, 0.15)",
    letterSpacing: 4,
  },
  cardCenter: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
  },
  flag: {
    fontSize: 80,
  },
  cardDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: 4,
  },
  cardBottom: {
    gap: 12,
  },
  cardDataRow: {
    flexDirection: "row",
    gap: 24,
  },
  cardDataItem: {
    gap: 4,
    flex: 1,
  },
  cardDataLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 9,
    color: Colors.textMuted,
    letterSpacing: 3,
  },
  cardDataValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    color: Colors.neonCyan,
    letterSpacing: 1,
  },
  cardDataValueFull: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    color: Colors.textSecondary,
    letterSpacing: 0,
    lineHeight: 18,
  },
  stamp: {
    position: "absolute",
    right: 20,
    bottom: 20,
    borderWidth: 2,
    borderColor: "rgba(0, 245, 255, 0.4)",
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    transform: [{ rotate: "-12deg" }],
  },
  stampText: {
    fontFamily: "Inter_700Bold",
    fontSize: 10,
    color: "rgba(0, 245, 255, 0.5)",
    letterSpacing: 3,
  },
  descContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
    paddingHorizontal: 4,
    width: "100%",
  },
  quoteBar: {
    width: 2,
    height: "100%",
    backgroundColor: Colors.neonCyan,
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 6,
    minHeight: 40,
  },
  description: {
    fontFamily: "Inter_500Medium",
    fontSize: 16,
    color: Colors.text,
    lineHeight: 24,
    flex: 1,
    textShadowColor: Colors.neonCyan,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 6,
  },
  buttonContainer: {
    width: "100%",
    paddingTop: 8,
  },
  retryButton: {
    width: "100%",
    height: 52,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.03)",
  },
  retryButtonText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    color: Colors.textSecondary,
    letterSpacing: 4,
  },
});
