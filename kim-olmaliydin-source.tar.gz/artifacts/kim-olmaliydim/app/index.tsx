import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  Easing,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { ParticleField } from "@/components/ParticleField";

const { width, height } = Dimensions.get("window");

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const titleOpacity = useRef(new Animated.Value(0)).current;
  const titleTranslate = useRef(new Animated.Value(20)).current;
  const subtitleOpacity = useRef(new Animated.Value(0)).current;
  const buttonOpacity = useRef(new Animated.Value(0)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const glowPulse = useRef(new Animated.Value(0)).current;
  const pressScale = useRef(new Animated.Value(1)).current;

  const analyzingDots = useRef(new Animated.Value(0)).current;
  const analyzingGlow = useRef(new Animated.Value(0)).current;
  const scanLine = useRef(new Animated.Value(-1)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.delay(300),
      Animated.parallel([
        Animated.timing(titleOpacity, {
          toValue: 1,
          duration: 800,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: false,
        }),
        Animated.timing(titleTranslate, {
          toValue: 0,
          duration: 800,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: false,
        }),
      ]),
      Animated.delay(200),
      Animated.parallel([
        Animated.timing(subtitleOpacity, {
          toValue: 1,
          duration: 600,
          useNativeDriver: false,
        }),
      ]),
      Animated.delay(100),
      Animated.parallel([
        Animated.timing(buttonOpacity, {
          toValue: 1,
          duration: 600,
          useNativeDriver: false,
        }),
        Animated.spring(buttonScale, {
          toValue: 1,
          friction: 6,
          tension: 100,
          useNativeDriver: false,
        }),
      ]),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(glowPulse, {
          toValue: 1,
          duration: 2000,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
        Animated.timing(glowPulse, {
          toValue: 0,
          duration: 2000,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
      ])
    ).start();
  }, []);

  const startAnalyzing = () => {
    if (isAnalyzing) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setIsAnalyzing(true);

    Animated.loop(
      Animated.timing(analyzingDots, {
        toValue: 3,
        duration: 900,
        easing: Easing.linear,
        useNativeDriver: false,
      })
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(analyzingGlow, {
          toValue: 1,
          duration: 700,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
        Animated.timing(analyzingGlow, {
          toValue: 0.3,
          duration: 700,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
      ])
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(scanLine, {
          toValue: 1,
          duration: 1200,
          easing: Easing.linear,
          useNativeDriver: false,
        }),
        Animated.timing(scanLine, {
          toValue: -1,
          duration: 0,
          useNativeDriver: false,
        }),
      ])
    ).start();

    setTimeout(() => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.push("/result");
    }, 3000);
  };

  const glowOpacity = glowPulse.interpolate({
    inputRange: [0, 1],
    outputRange: [0.4, 0.9],
  });

  const scanTranslate = scanLine.interpolate({
    inputRange: [-1, 1],
    outputRange: [-height * 0.25, height * 0.25],
  });

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ParticleField />

      <View style={styles.content}>
        <Animated.View
          style={[
            styles.titleContainer,
            {
              opacity: titleOpacity,
              transform: [{ translateY: titleTranslate }],
            },
          ]}
        >
          <Animated.View
            style={[
              styles.titleGlow,
              { opacity: glowOpacity },
            ]}
          />
          <Text style={styles.titleLine1}>KIM</Text>
          <Text style={styles.titleLine2}>OLMALIYDIM?</Text>
          <View style={styles.titleUnderline} />
        </Animated.View>

        <Animated.Text style={[styles.subtitle, { opacity: subtitleOpacity }]}>
          Ruhunun ait olduğu yeri keşfet
        </Animated.Text>

        <Animated.View
          style={[
            styles.buttonWrapper,
            {
              opacity: buttonOpacity,
              transform: [{ scale: buttonScale }],
            },
          ]}
        >
          {!isAnalyzing ? (
            <Pressable
              onPress={startAnalyzing}
              onPressIn={() => {
                Animated.spring(pressScale, {
                  toValue: 0.95,
                  friction: 6,
                  useNativeDriver: false,
                }).start();
              }}
              onPressOut={() => {
                Animated.spring(pressScale, {
                  toValue: 1,
                  friction: 6,
                  useNativeDriver: false,
                }).start();
              }}
            >
              <Animated.View
                style={[
                  styles.button,
                  { transform: [{ scale: pressScale }] },
                ]}
              >
                <View style={styles.buttonGlow} />
                <Text style={styles.buttonText}>RUHUNU KEŞFET</Text>
                <View style={styles.buttonCornerTL} />
                <View style={styles.buttonCornerTR} />
                <View style={styles.buttonCornerBL} />
                <View style={styles.buttonCornerBR} />
              </Animated.View>
            </Pressable>
          ) : (
            <Animated.View style={[styles.analyzingBox, { opacity: analyzingGlow }]}>
              <View style={styles.analyzingScanContainer}>
                <Animated.View
                  style={[
                    styles.scanLine,
                    { transform: [{ translateY: scanTranslate }] },
                  ]}
                />
              </View>
              <AnalyzingText animValue={analyzingDots} />
              <View style={styles.analyzingCornerTL} />
              <View style={styles.analyzingCornerTR} />
              <View style={styles.analyzingCornerBL} />
              <View style={styles.analyzingCornerBR} />
            </Animated.View>
          )}
        </Animated.View>

        <Animated.Text style={[styles.footer, { opacity: subtitleOpacity }]}>
          ✦ 5 olası ruh ülkesi ✦
        </Animated.Text>
      </View>
    </View>
  );
}

function AnalyzingText({ animValue }: { animValue: Animated.Value }) {
  const [dots, setDots] = React.useState(".");

  React.useEffect(() => {
    const id = setInterval(() => {
      setDots((d) => (d.length >= 3 ? "." : d + "."));
    }, 400);
    return () => clearInterval(id);
  }, []);

  return (
    <View style={styles.analyzingTextContainer}>
      <Text style={styles.analyzingLabel}>ANALİZ EDİLİYOR{dots}</Text>
      <Text style={styles.analyzingSubLabel}>Ruhun taranıyor</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    gap: 28,
  },
  titleContainer: {
    alignItems: "center",
    position: "relative",
  },
  titleGlow: {
    position: "absolute",
    width: 300,
    height: 120,
    backgroundColor: Colors.neonCyanGlow,
    borderRadius: 60,
    top: -10,
    alignSelf: "center",
    filter: undefined,
  },
  titleLine1: {
    fontFamily: "Inter_700Bold",
    fontSize: 58,
    color: Colors.text,
    letterSpacing: 20,
    textShadowColor: Colors.neonCyan,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
    lineHeight: 62,
  },
  titleLine2: {
    fontFamily: "Inter_700Bold",
    fontSize: 34,
    color: Colors.neonCyan,
    letterSpacing: 8,
    textShadowColor: Colors.neonCyan,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 25,
    lineHeight: 40,
  },
  titleUnderline: {
    marginTop: 12,
    width: 80,
    height: 1,
    backgroundColor: Colors.neonCyan,
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 5,
  },
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    color: Colors.textSecondary,
    letterSpacing: 3,
    textTransform: "uppercase",
    textAlign: "center",
  },
  buttonWrapper: {
    width: "100%",
    alignItems: "center",
    marginTop: 8,
  },
  button: {
    width: width * 0.78,
    height: 64,
    borderWidth: 1,
    borderColor: Colors.neonCyan,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0, 245, 255, 0.06)",
    position: "relative",
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 20,
    elevation: 8,
  },
  buttonGlow: {
    position: "absolute",
    inset: 0,
    backgroundColor: "rgba(0, 245, 255, 0.05)",
  },
  buttonText: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    color: Colors.neonCyan,
    letterSpacing: 4,
    textShadowColor: Colors.neonCyan,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  buttonCornerTL: {
    position: "absolute",
    top: -2,
    left: -2,
    width: 12,
    height: 12,
    borderTopWidth: 2,
    borderLeftWidth: 2,
    borderColor: Colors.neonCyan,
  },
  buttonCornerTR: {
    position: "absolute",
    top: -2,
    right: -2,
    width: 12,
    height: 12,
    borderTopWidth: 2,
    borderRightWidth: 2,
    borderColor: Colors.neonCyan,
  },
  buttonCornerBL: {
    position: "absolute",
    bottom: -2,
    left: -2,
    width: 12,
    height: 12,
    borderBottomWidth: 2,
    borderLeftWidth: 2,
    borderColor: Colors.neonCyan,
  },
  buttonCornerBR: {
    position: "absolute",
    bottom: -2,
    right: -2,
    width: 12,
    height: 12,
    borderBottomWidth: 2,
    borderRightWidth: 2,
    borderColor: Colors.neonCyan,
  },
  analyzingBox: {
    width: width * 0.78,
    height: 120,
    borderWidth: 1,
    borderColor: Colors.neonCyan,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0, 245, 255, 0.04)",
    position: "relative",
    overflow: "hidden",
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 30,
    elevation: 10,
  },
  analyzingScanContainer: {
    position: "absolute",
    inset: 0,
    overflow: "hidden",
  },
  scanLine: {
    position: "absolute",
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: Colors.neonCyan,
    opacity: 0.7,
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 10,
    top: "50%",
  },
  analyzingTextContainer: {
    alignItems: "center",
    gap: 6,
  },
  analyzingLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
    color: Colors.neonCyan,
    letterSpacing: 4,
    textShadowColor: Colors.neonCyan,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  analyzingSubLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    color: Colors.textMuted,
    letterSpacing: 2,
  },
  analyzingCornerTL: {
    position: "absolute",
    top: -2,
    left: -2,
    width: 14,
    height: 14,
    borderTopWidth: 2,
    borderLeftWidth: 2,
    borderColor: Colors.neonCyan,
  },
  analyzingCornerTR: {
    position: "absolute",
    top: -2,
    right: -2,
    width: 14,
    height: 14,
    borderTopWidth: 2,
    borderRightWidth: 2,
    borderColor: Colors.neonCyan,
  },
  analyzingCornerBL: {
    position: "absolute",
    bottom: -2,
    left: -2,
    width: 14,
    height: 14,
    borderBottomWidth: 2,
    borderLeftWidth: 2,
    borderColor: Colors.neonCyan,
  },
  analyzingCornerBR: {
    position: "absolute",
    bottom: -2,
    right: -2,
    width: 14,
    height: 14,
    borderBottomWidth: 2,
    borderRightWidth: 2,
    borderColor: Colors.neonCyan,
  },
  footer: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    color: Colors.textMuted,
    letterSpacing: 3,
  },
});
