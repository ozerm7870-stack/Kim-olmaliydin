const NEON_CYAN = "#00F5FF";
const NEON_CYAN_DIM = "#00C8CC";
const NEON_CYAN_GLOW = "rgba(0, 245, 255, 0.3)";
const DARK_BG = "#050A14";
const DARK_SURFACE = "#0D1826";
const DARK_CARD = "#111D2E";
const DARK_BORDER = "rgba(0, 245, 255, 0.15)";

export default {
  neonCyan: NEON_CYAN,
  neonCyanDim: NEON_CYAN_DIM,
  neonCyanGlow: NEON_CYAN_GLOW,
  background: DARK_BG,
  surface: DARK_SURFACE,
  card: DARK_CARD,
  border: DARK_BORDER,
  text: "#FFFFFF",
  textSecondary: "rgba(255, 255, 255, 0.6)",
  textMuted: "rgba(255, 255, 255, 0.35)",
};
