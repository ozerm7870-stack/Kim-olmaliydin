import React, { useEffect, useRef } from "react";
import { Animated, Dimensions, Easing, StyleSheet, View } from "react-native";
import Colors from "@/constants/colors";

const { width, height } = Dimensions.get("window");

type Particle = {
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  opacity: number;
};

function generateParticles(count: number): Particle[] {
  return Array.from({ length: count }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    size: Math.random() * 2 + 0.5,
    duration: Math.random() * 4000 + 3000,
    delay: Math.random() * 3000,
    opacity: Math.random() * 0.6 + 0.1,
  }));
}

function Particle({ particle }: { particle: Particle }) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.delay(particle.delay),
        Animated.timing(anim, {
          toValue: 1,
          duration: particle.duration,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
        Animated.timing(anim, {
          toValue: 0,
          duration: particle.duration,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: false,
        }),
      ])
    ).start();
  }, []);

  const opacity = anim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, particle.opacity],
  });

  return (
    <Animated.View
      style={[
        styles.particle,
        {
          left: particle.x,
          top: particle.y,
          width: particle.size,
          height: particle.size,
          borderRadius: particle.size / 2,
          opacity,
        },
      ]}
    />
  );
}

const PARTICLES = generateParticles(35);

export function ParticleField() {
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {PARTICLES.map((p, i) => (
        <Particle key={i} particle={p} />
      ))}
      <View style={styles.gridLine1} />
      <View style={styles.gridLine2} />
      <View style={styles.gridLine3} />
      <View style={styles.gridLineH1} />
      <View style={styles.gridLineH2} />
      <View style={styles.vignetteTop} />
      <View style={styles.vignetteBottom} />
    </View>
  );
}

const styles = StyleSheet.create({
  particle: {
    position: "absolute",
    backgroundColor: Colors.neonCyan,
    shadowColor: Colors.neonCyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 4,
  },
  gridLine1: {
    position: "absolute",
    left: width * 0.25,
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: "rgba(0, 245, 255, 0.03)",
  },
  gridLine2: {
    position: "absolute",
    left: width * 0.5,
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: "rgba(0, 245, 255, 0.03)",
  },
  gridLine3: {
    position: "absolute",
    left: width * 0.75,
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: "rgba(0, 245, 255, 0.03)",
  },
  gridLineH1: {
    position: "absolute",
    top: height * 0.33,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: "rgba(0, 245, 255, 0.03)",
  },
  gridLineH2: {
    position: "absolute",
    top: height * 0.66,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: "rgba(0, 245, 255, 0.03)",
  },
  vignetteTop: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 200,
    backgroundColor: "transparent",
  },
  vignetteBottom: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 200,
    backgroundColor: "transparent",
  },
});
